var PRODUCTS = {
    'items': [{
        "id": 1,
        "name": "Product 1",
        "price": "10",
        "description": "Women clothing description",        
        "image":"https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/gala-gonzalez-wears-a-tan-color-suede-jacket-a-green-dior-news-photo-1578511763.jpg?crop=1xw:1xh;center,top&resize=480:*"
    }, 
    {
        "id": 2,
        "name": "Product 2",
        "price": "20",
        "description": "Women clothing description",
        "image": "https://femina.wwmindia.com/content/2021/jul/dress-031627300975.jpg"
    }, 
        
    {
        "id": 3,
        "name": "Product 3",
        "price": "30",
        "description": "Women clothing description",
        "image": "https://assets.panashindia.com/media/catalog/product/cache/1/small_image/262x377/9df78eab33525d08d6e5fb8d27136e95/2/4/247tb01-1231.jpg"
    }, 
        
    {
        "id": 4,
        "name": "Product 4",
        "price": "40",
        "description": "Women clothing description",
        "image": "https://sslimages.shoppersstop.com/sys-master/images/h60/ha5/26863979888670/S22EP1211NAVYB_NAVY_BLUE.jpg_230Wx334H"
    }, 
        
    {
        "id": 5,
        "name": "Product 5",
        "price": "50",
        "description": "Women clothing description",
        "image": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSG7yoBPmEdHzJ3YF-1fZSgTXInMU1TxSEtTEWoq_rWUZLT2ZdlnG_C8vtWhTWuEktUyMs&usqp=CAU"
    }, 
    
    {
        "id": 6,
        "name": "Product 6",
        "price": "60",
        "description": "Women clothing description",
        "image": "https://femina.wwmindia.com/content/2021/jul/dress-031627300975.jpg"
        },

        {
            "id": 7,
            "name": "Product 7",
            "price": "70",
            "description": "Women clothing description",
            "image": "https://assets.panashindia.com/media/catalog/product/cache/1/small_image/262x377/9df78eab33525d08d6e5fb8d27136e95/2/4/247tb01-1231.jpg"
        },
        {
            "id": 8,
            "name": "Product 8",
            "price": "80",
            "description": "Women clothing description",
            "image": "https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/gala-gonzalez-wears-a-tan-color-suede-jacket-a-green-dior-news-photo-1578511763.jpg?crop=1xw:1xh;center,top&resize=480:*"
        },

        {
            "id": 9,
            "name": "Product 9",
            "price": "90",
            "description": "Women clothing description",
            "image": "https://sslimages.shoppersstop.com/sys-master/images/h60/ha5/26863979888670/S22EP1211NAVYB_NAVY_BLUE.jpg_230Wx334H"
        },

        {
            "id": 10,
            "name": "Product 10",
            "price": "100",
            "description": "Women clothing description",
            "image": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSG7yoBPmEdHzJ3YF-1fZSgTXInMU1TxSEtTEWoq_rWUZLT2ZdlnG_C8vtWhTWuEktUyMs&usqp=CAU"
        },  
    ],
};

module.exports = {
    PRODUCTS: PRODUCTS
};