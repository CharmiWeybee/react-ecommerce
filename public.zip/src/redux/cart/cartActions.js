import {ADD_TO_CART} from './cartTypes'


export const addtocart = ()=>{
    return{
        type: ADD_TO_CART
    }
}