import  {ADD_TO_CART} from './cartTypes'


const initialState = {}

const cartReducer = (state=initialState, action) =>{
    switch(action.type){
        case ADD_TO_CART: return {
            console.log('')        
        }

        default: return state
    }
}