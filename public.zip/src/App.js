import React from 'react';
import {Routes,Route,} from "react-router-dom";
import './App.css';
import { Main } from './components/Main';
import { CartList } from './components/CartList';



function App() {

  return (
      <Routes>
        <Route path="/" element={<Main />}></Route> 
        <Route path="/cart" element={<CartList />} ></Route>         
      </Routes>
  );
}

export default App;

