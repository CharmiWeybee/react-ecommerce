import React from 'react'

export const CartList = (cartItems) => {
    console.log(cartItems)
    return (
        <div>
           Cart
        </div>
      
    );
}


